import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { ListviewComponent } from './listview/listview.component';
import { OrdersComponent } from './orders/orders.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CardComponent } from './card/card.component';
import { TedComponent } from './ted/ted.component';
import { EditComponent } from './edit/edit.component';
import { AddComponent } from './add/add.component';
import { SerComponent } from './ser/ser.component';


@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    ListviewComponent,
    OrdersComponent,
    AboutComponent,
    LoginComponent,
    CardComponent,
    TedComponent,
    EditComponent,
    AddComponent,
    SerComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
